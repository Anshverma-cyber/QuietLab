# QuietLab Android

Native Android audio passthrough / polarity-inversion experiment.

## Build APK with GitHub Actions
1. Create a GitHub repository and upload the contents of this folder to its root.
2. Commit the files to the `main` branch.
3. Open the repository's **Actions** tab.
4. Open **Build QuietLab APK** and wait for the workflow to finish.
5. Open the completed run and download the `QuietLab-debug-APK` artifact.
6. Extract the ZIP; install `app-debug.apk` on your Android phone.
7. If Android blocks installation, allow your browser/file manager to install unknown apps.

## Run
1. Connect Bluetooth earbuds first.
2. Open QuietLab and grant microphone permission.
3. Keep output gain low (start at 5–10%).
4. Tap START AUDIO. Tap STOP to end.

## Technical limitation
This app captures the phone microphone and plays a low-gain, optionally polarity-inverted copy through Android media output. It is NOT true ANC. Effective active cancellation requires a reference microphone near the ear, accurate acoustic-path modelling, and very low end-to-end latency. Bluetooth latency makes this setup unsuitable for dependable noise cancellation. Do not use speakers or high gain; stop if feedback or discomfort occurs.
