package com.quietlab.anc;

import android.Manifest;
import android.app.Activity;
import android.content.pm.PackageManager;
import android.media.AudioAttributes;
import android.media.AudioFormat;
import android.media.AudioRecord;
import android.media.AudioTrack;
import android.media.MediaRecorder;
import android.os.Bundle;
import android.os.Process;
import android.view.Gravity;
import android.view.View;
import android.widget.Button;
import android.widget.LinearLayout;
import android.widget.SeekBar;
import android.widget.Switch;
import android.widget.TextView;
import android.widget.Toast;

public class MainActivity extends Activity {
    private static final int REQUEST_MIC = 41;
    private static final int RATE = 48000;

    private AudioRecord recorder;
    private AudioTrack player;
    private Thread audioThread;
    private volatile boolean running = false;
    private volatile boolean inverted = false;
    private volatile boolean muted = false;
    private volatile float gain = 0.10f;

    private TextView status;
    private TextView gainText;
    private Button startButton;
    private Button stopButton;

    @Override public void onCreate(Bundle state) {
        super.onCreate(state);
        buildUi();
        updateButtons(false);
    }

    private void buildUi() {
        LinearLayout page = new LinearLayout(this);
        page.setOrientation(LinearLayout.VERTICAL);
        page.setPadding(dp(22), dp(28), dp(22), dp(22));
        page.setBackgroundColor(0xFF0A1020);

        TextView title = new TextView(this);
        title.setText("QUIETLAB");
        title.setTextColor(0xFF78E0C3);
        title.setTextSize(13);
        title.setLetterSpacing(0.18f);
        page.addView(title);

        TextView heading = new TextView(this);
        heading.setText("Software ANC Lab");
        heading.setTextColor(0xFFF0F5FF);
        heading.setTextSize(29);
        heading.setPadding(0, dp(7), 0, dp(4));
        page.addView(heading);

        TextView subtitle = new TextView(this);
        subtitle.setText("Native microphone monitoring and phase-inversion experiment");
        subtitle.setTextColor(0xFFAAB8D0);
        subtitle.setTextSize(14);
        page.addView(subtitle);

        status = new TextView(this);
        status.setText("Engine stopped");
        status.setTextColor(0xFFB7C5DC);
        status.setTextSize(14);
        status.setPadding(0, dp(24), 0, dp(12));
        page.addView(status);

        startButton = new Button(this);
        startButton.setText("START AUDIO");
        startButton.setOnClickListener(v -> startWithPermission());
        page.addView(startButton);

        stopButton = new Button(this);
        stopButton.setText("STOP");
        stopButton.setOnClickListener(v -> stopAudio());
        page.addView(stopButton);

        Switch phase = new Switch(this);
        phase.setText("Phase inversion (polarity flip)");
        phase.setTextColor(0xFFE8EFFB);
        phase.setPadding(0, dp(22), 0, dp(10));
        phase.setOnCheckedChangeListener((b, checked) -> inverted = checked);
        page.addView(phase);

        Switch mute = new Switch(this);
        mute.setText("Mute output (meter/safety test)");
        mute.setTextColor(0xFFE8EFFB);
        mute.setPadding(0, dp(8), 0, dp(10));
        mute.setOnCheckedChangeListener((b, checked) -> muted = checked);
        page.addView(mute);

        gainText = new TextView(this);
        gainText.setText("Output gain: 10%");
        gainText.setTextColor(0xFFE8EFFB);
        gainText.setPadding(0, dp(18), 0, dp(4));
        page.addView(gainText);

        SeekBar gainBar = new SeekBar(this);
        gainBar.setMax(25);
        gainBar.setProgress(10);
        gainBar.setOnSeekBarChangeListener(new SeekBar.OnSeekBarChangeListener() {
            @Override public void onProgressChanged(SeekBar bar, int value, boolean user) {
                gain = value / 100.0f;
                gainText.setText("Output gain: " + value + "%");
            }
            @Override public void onStartTrackingTouch(SeekBar bar) {}
            @Override public void onStopTrackingTouch(SeekBar bar) {}
        });
        page.addView(gainBar);

        TextView note = new TextView(this);
        note.setText("SAFETY: Connect earbuds before starting. Keep gain low. Stop if you hear feedback, loud tones or discomfort. This prototype does not provide verified ANC.");
        note.setTextColor(0xFFFFDDA0);
        note.setTextSize(13);
        note.setPadding(dp(14), dp(16), dp(14), dp(16));
        note.setBackgroundColor(0xFF302719);
        LinearLayout.LayoutParams noteParams = new LinearLayout.LayoutParams(
                LinearLayout.LayoutParams.MATCH_PARENT, LinearLayout.LayoutParams.WRAP_CONTENT);
        noteParams.topMargin = dp(22);
        page.addView(note, noteParams);

        TextView route = new TextView(this);
        route.setText("Bluetooth output: Android media audio routing. Connect earbuds in Bluetooth settings before pressing Start.");
        route.setTextColor(0xFF9AABC6);
        route.setTextSize(12);
        route.setPadding(0, dp(16), 0, 0);
        page.addView(route);

        setContentView(page);
    }

    private void startWithPermission() {
        if (checkSelfPermission(Manifest.permission.RECORD_AUDIO) != PackageManager.PERMISSION_GRANTED) {
            requestPermissions(new String[]{Manifest.permission.RECORD_AUDIO}, REQUEST_MIC);
        } else {
            startAudio();
        }
    }

    @Override public void onRequestPermissionsResult(int requestCode, String[] permissions, int[] results) {
        super.onRequestPermissionsResult(requestCode, permissions, results);
        if (requestCode == REQUEST_MIC) {
            if (results.length > 0 && results[0] == PackageManager.PERMISSION_GRANTED) startAudio();
            else status.setText("Microphone permission denied. Allow it in Android app settings.");
        }
    }

    private void startAudio() {
        if (running) return;
        int minIn = AudioRecord.getMinBufferSize(RATE, AudioFormat.CHANNEL_IN_MONO,
                AudioFormat.ENCODING_PCM_16BIT);
        int minOut = AudioTrack.getMinBufferSize(RATE, AudioFormat.CHANNEL_OUT_MONO,
                AudioFormat.ENCODING_PCM_16BIT);
        if (minIn <= 0 || minOut <= 0) {
            status.setText("This device does not support the requested audio format.");
            return;
        }
        int bufferBytes = Math.max(Math.max(minIn, minOut) * 2, 4096);
        try {
            recorder = new AudioRecord.Builder()
                    .setAudioSource(MediaRecorder.AudioSource.MIC)
                    .setAudioFormat(new AudioFormat.Builder()
                            .setSampleRate(RATE)
                            .setEncoding(AudioFormat.ENCODING_PCM_16BIT)
                            .setChannelMask(AudioFormat.CHANNEL_IN_MONO)
                            .build())
                    .setBufferSizeInBytes(bufferBytes)
                    .build();

            player = new AudioTrack.Builder()
                    .setAudioAttributes(new AudioAttributes.Builder()
                            .setUsage(AudioAttributes.USAGE_MEDIA)
                            .setContentType(AudioAttributes.CONTENT_TYPE_MUSIC)
                            .build())
                    .setAudioFormat(new AudioFormat.Builder()
                            .setSampleRate(RATE)
                            .setEncoding(AudioFormat.ENCODING_PCM_16BIT)
                            .setChannelMask(AudioFormat.CHANNEL_OUT_MONO)
                            .build())
                    .setTransferMode(AudioTrack.MODE_STREAM)
                    .setBufferSizeInBytes(bufferBytes)
                    .build();

            if (recorder.getState() != AudioRecord.STATE_INITIALIZED ||
                    player.getState() != AudioTrack.STATE_INITIALIZED) {
                throw new IllegalStateException("Audio hardware initialization failed.");
            }
            recorder.startRecording();
            player.play();
            running = true;
            updateButtons(true);
            status.setText("Running · 48 kHz · connect Bluetooth earbuds for output");

            audioThread = new Thread(() -> {
                Process.setThreadPriority(Process.THREAD_PRIORITY_AUDIO);
                short[] samples = new short[1024];
                try {
                    while (running) {
                        int count = recorder.read(samples, 0, samples.length, AudioRecord.READ_BLOCKING);
                        if (count > 0) {
                            float localGain = muted ? 0f : gain;
                            boolean flip = inverted;
                            for (int i = 0; i < count; i++) {
                                int sample = samples[i];
                                if (flip) sample = -sample;
                                int out = Math.round(sample * localGain);
                                if (out > 32767) out = 32767;
                                if (out < -32768) out = -32768;
                                samples[i] = (short) out;
                            }
                            int written = 0;
                            while (written < count && running) {
                                int n = player.write(samples, written, count - written, AudioTrack.WRITE_BLOCKING);
                                if (n < 0) throw new IllegalStateException("Audio output error: " + n);
                                written += n;
                            }
                        } else if (count < 0) {
                            throw new IllegalStateException("Microphone read error: " + count);
                        }
                    }
                } catch (Exception e) {
                    runOnUiThread(() -> status.setText("Audio stopped: " + e.getMessage()));
                    running = false;
                }
                runOnUiThread(() -> updateButtons(false));
            }, "QuietLab-Audio");
            audioThread.start();
        } catch (Exception e) {
            status.setText("Could not start: " + e.getMessage());
            releaseAudio();
            updateButtons(false);
        }
    }

    private void stopAudio() {
        running = false;
        if (recorder != null) {
            try { recorder.stop(); } catch (Exception ignored) {}
        }
        if (audioThread != null) {
            try { audioThread.join(500); } catch (InterruptedException ignored) {}
            audioThread = null;
        }
        releaseAudio();
        status.setText("Engine stopped");
        updateButtons(false);
    }

    private void releaseAudio() {
        if (recorder != null) { try { recorder.release(); } catch (Exception ignored) {} recorder = null; }
        if (player != null) { try { player.pause(); player.flush(); player.release(); } catch (Exception ignored) {} player = null; }
    }

    private void updateButtons(boolean active) {
        startButton.setEnabled(!active);
        stopButton.setEnabled(active);
    }

    private int dp(int value) {
        return Math.round(value * getResources().getDisplayMetrics().density);
    }

    @Override protected void onStop() {
        super.onStop();
        stopAudio();
    }
}
